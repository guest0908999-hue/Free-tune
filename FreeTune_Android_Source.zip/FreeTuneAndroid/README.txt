
FreeTune Android starter project
================================

This is a native Android wrapper around a local web music UI. It includes:
- Dark mobile UI
- Jamendo catalogue search
- Streaming via HTML audio player
- Favourites saved on the device
- Download button only when Jamendo says audiodownload_allowed=true

IMPORTANT:
1. Create a Jamendo developer account and app/client ID at https://devportal.jamendo.com/
2. Open app/src/main/assets/index.html and replace:
   PASTE_YOUR_JAMENDO_CLIENT_ID_HERE
   with your actual client ID.
3. Build the Android APK.

BUILD ON YOUR ANDROID PHONE (one route):
- Install AndroidIDE from its official project page / supported distribution.
- Extract this ZIP into a folder on your phone.
- Open the project folder in AndroidIDE and allow Gradle sync/downloads.
- Build/Run the app. The debug APK is typically under:
  app/build/outputs/apk/debug/app-debug.apk
- Tap the APK to install. Android may ask you to allow installs from that file manager.

If AndroidIDE cannot sync this Gradle version on your device, build with Android Studio on a computer.
Official Android build docs: https://developer.android.com/build/building-cmdline

NOTES:
- Requires internet for search/streaming.
- The download control appears only when the API explicitly permits the track download.
- Review Jamendo's API terms and each track's licence before redistribution.
- This is a starter project, not yet a Play Store-ready release.


BUILD WITHOUT A COMPUTER (GitHub Actions from your phone):
1. Create/sign in to a GitHub account in your phone browser: https://github.com/
2. Create a new repository, e.g. FreeTuneAndroid.
3. Upload the CONTENTS of this project folder to the repository (keep the .github/workflows/build-apk.yml file).
4. Open the repository's Actions tab. If prompted, enable Actions.
5. Choose "Build FreeTune APK" and tap "Run workflow" (or wait for the push build).
6. When the run turns green, open that run and download the "FreeTune-debug-apk" artifact.
7. Extract the downloaded artifact ZIP; tap app-debug.apk to install.

Note: This produces a debug APK, not a Play Store release. Add your Jamendo client ID
in app/src/main/assets/index.html before uploading if you want music search to work.
